import { Avatar, Button, Card, TextField, Typography } from '@mui/material';
import React, { useState } from 'react';
import CloseIcon from '@mui/icons-material/Close';
function ToasterCom2({ message ,clickClose}) {

  return (
    <div>
       <Card sx={{backgroundColor:"green", padding:"10px" , width:"100px" , mb:"20px"}}>
     
       {message}
     <Avatar sx={{ position: 'absolute', top: '10px', right: '5px',p:'2px',width: 20, height: 20}} >
     <CloseIcon onClick={clickClose} />
     </Avatar>
  
  </Card>
 
    </div>
  );
}

export default ToasterCom2;
