import { Avatar, Card } from '@mui/material'
import React from 'react'
import CloseIcon from '@mui/icons-material/Close';

function ToastComp({showtaostmessagefalse}) {
  return (
    <div>
        <Card sx={{backgroundColor:"green", padding:"10px" , width:"100px" , mb:"20px"}}>
     
           Testing
           <Avatar sx={{ position: 'absolute', top: '10px', right: '5px',p:'2px',width: 20, height: 20}} >
           <CloseIcon onClick={showtaostmessagefalse}/>
           </Avatar>
        
        </Card>
    
    </div>
  )
}

export default ToastComp