import React, { useState, useEffect } from 'react';
import axios from 'axios';

function TimerWithApiCall() {
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [timerDuration, setTimerDuration] = useState(4); // Default timer duration is 4 seconds

  useEffect(() => {
    let interval;

    if (isRunning) {
      interval = setInterval(() => {
        setSeconds(prevSeconds => prevSeconds + 1);
      }, 1000);

      if (seconds === timerDuration) {
        // Call your API here
        callApiForCityList();

        // Reset the timer
        setSeconds(0);
        setIsRunning(false);
      }
    }

    return () => clearInterval(interval);
  }, [isRunning, seconds, timerDuration]);

  const handleStart = () => {
    setIsRunning(true);
  };

  const handlePause = () => {
    setIsRunning(false);
  };

  const handleReset = () => {
    setSeconds(0);
    setIsRunning(false);
  };

  const handleSetTime = (timeInSeconds) => {
    setTimerDuration(timeInSeconds);
  };

  const callApiForCityList = () => {
    // Replace this with your actual API call
    axios.get("https://api.example.com/city-list")
      .then(response => {
        console.log("City List:", response.data);
        // Handle the city list data here
      })
      .catch(error => {
        console.error("Error fetching city list:", error);
      });
  };

  return (
    <div>
      <h1>{seconds}s</h1>
      <button onClick={handleStart} disabled={isRunning}>
        Start
      </button>
   
      <br />
      <label>
        Set Time (in seconds):
        <input type="number" onChange={(e) => handleSetTime(parseInt(e.target.value, 10))} />
      </label>
    </div>
  );
}

export default TimerWithApiCall;
