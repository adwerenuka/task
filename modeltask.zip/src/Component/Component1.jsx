import { Box, Button, Dialog } from '@mui/material'
import React, { useState } from 'react'
import ToastComp from './ToastComp'
import SettingsIcon from '@mui/icons-material/Settings';
import DialogBox from './DialogBox';


function Component1() {
    const [show, setShow] = useState(false)
    const [open, setOpen] = useState(false);
    const showtaostmessage = () => {
        setShow(true);
    }

    const showtaostmessagefalse = () => {
        setShow(false);
    }

    const handleClickOpen = () => {
        setOpen(true);


    };

    const handleClickClose = () => {
        setOpen(false);

    };
    return (
        <Box mt={5}>
            <Button onClick={showtaostmessage} variant='contained' sx={{backgroundColor:"#959ff8" , float:"left",ml:"30px" }}>showtaostmessage</Button>
            {show &&
                <Box sx={{ position: "absolute", bottom: "50px", left: '50%', }}>
                    <ToastComp showtaostmessagefalse={showtaostmessagefalse} />
                </Box>
            }
            <Button onClick={handleClickOpen} sx={{backgroundColor:"lightGray" , float:"left",ml:"10px"}}>
                <SettingsIcon sx={{color:"black" }}/>
            </Button>

            <Dialog open={open} onClose={handleClickClose}>
                <DialogBox handleClickClose={handleClickClose} />
            </Dialog>


        </Box>
    )
}

export default Component1