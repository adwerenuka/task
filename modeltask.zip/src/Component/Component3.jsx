import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Typography, Button, TextField, Box, List } from '@mui/material';
import CountDownTimer from './CountDownTimer';

function Component3() {
    const [taskList, setTaskList] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [isLoading, setIsLoading] = useState(false);
    const [show, setShow] = useState(false);
    const countriesPerPage = 5;

    const indexOfLastCountry = currentPage * countriesPerPage;
    const indexOfFirstCountry = indexOfLastCountry - countriesPerPage;
    const currentCountries = taskList.slice(indexOfFirstCountry, indexOfLastCountry);

    const handleNextPage = () => {
        setCurrentPage((prevPage) => prevPage + 1);
    };

    const handlePrevPage = () => {
        setCurrentPage((prevPage) => prevPage - 1);
    };

    const [seconds, setSeconds] = useState(0);
    const [isRunning, setIsRunning] = useState(false);
    const [timerDuration, setTimerDuration] = useState(4); // Default timer duration is 4 seconds

    useEffect(() => {
        let interval;

        if (isRunning) {
            interval = setInterval(() => {
                setSeconds((prevSeconds) => {
                    // Check if the timer duration is reached or exceeded
                    if (prevSeconds === timerDuration - 1) {
                        // Reset the timer
                        setSeconds(0);
                        setIsRunning(false);
                        // Call your API here
                        callApiForCityList();
                    } else {
                        return prevSeconds + 1;
                    }
                });
            }, 1000);
        }

        return () => clearInterval(interval);
    }, [isRunning, timerDuration]);

    const handleStart = () => {
        setSeconds(0);
        setIsRunning(true);
    };

    const handlePause = () => {
        setIsRunning(false);
    };

    const handleReset = () => {
        setSeconds(0);
        setIsRunning(false);
    };

    const handleSetTime = (timeInSeconds) => {
        setTimerDuration(timeInSeconds);
    };

    const callApiForCityList = () => {
        setIsLoading(true);
        // Replace this with your actual API call
        axios
            .get("https://api.knowmee.co/api/v1/master/get-country-list")
            .then((res) => {
                setTaskList(res.data?.responseData || []);
                setIsLoading(false);
                setShow(true); // Show the API list after fetching data
            })
            .catch((error) => {
                console.error("Error fetching city list:", error);
                setIsLoading(false);
            });
    };

    return (
        <>
            {!show ? (
                <Box sx={{ float: "left", ml: "30px" }}>
                    <div>
                        <br />
                        <Typography> Enter Countdown Time: </Typography>
                        <label>
                            <TextField
                                type="number"
                                onChange={(e) => handleSetTime(parseInt(e.target.value, 10))}
                                size="small"
                                placeholder="Enter Here"
                            />
                        </label>
                        <br></br>
                        <br></br>
                        <br></br>
                        <Button onClick={handleStart} disabled={isRunning} variant="contained">
                            Start Timer
                        </Button>
                        {isRunning && (
                            <Box sx={{ position: "absolute", bottom: "50px", left: "50%" }}>
                                <CountDownTimer seconds={seconds} />
                            </Box>
                        )}
                        <br></br>
                        <br></br>
                    </div>
                </Box>
            ) : (
                <>
                    {isLoading ? (
                        <p>Please wait, data is being fetched...</p>
                    ) : (
                        <>
                            <div>

                            {taskList.length && (
                                    <Box sx={{float:"right" , mr:"80px"}} mt={4}>
                                        <Button
                                            onClick={handlePrevPage}
                                            disabled={currentPage === 1}
                                            variant="contained"
                                            sx={{
                                                backgroundColor: "#beb",
                                                mr:"30px",
                                                width:"100px",
                                                textTransform: "capitalize",
                                                color: "black",
                                                "&:hover": {
                                                    backgroundColor: "#beb",
                                                },
                                            }}
                                        >
                                            Previous
                                        </Button>
                                     
                                        <Button
                                            onClick={handleNextPage}
                                            disabled={indexOfLastCountry >= taskList.length}
                                            variant="contained"
                                            sx={{
                                                backgroundColor: "#beb",
                                                textTransform: "capitalize",
                                                color: "black",
                                                width:"100px",
                                                "&:hover": {
                                                    backgroundColor: "#beb",
                                                },
                                            }}
                                        >
                                            Next
                                        </Button>
                                    </Box>
                                )}
                                <Box sx={{float:"left" , ml:"80px"}} mt={10}>
                                {currentCountries.map((item, i) => (
                                    <Box key={i}> 
                                        <List>
                                        <Typography sx={{textAlign:"left"}}>{item.country_name}</Typography>
                                        </List>
                                    
                                    </Box>
                                ))}
                                </Box>
                             

                               
                            </div>
                        </>
                    )}
                </>
            )}
        </>
    );
}

export default Component3;
