import { Box, Button, TextField, Typography } from '@mui/material';
import React, { useState } from 'react';
import TaosterCom2 from './TaosterCom2';
import ToastComp from './ToastComp';
import ToasterCom2 from './TaosterCom2';
import CloseIcon from '@mui/icons-material/Close';
function Component2() {


    const [message, setMessage] = useState('');
    const [toaster, setToaster] = useState('');
   
    const showToaster = (e) => {
        setToaster(message);

    };

    const clickClose = () => {
        setToaster('');
    };

    return (
        <Box sx={{float:"left"}} mt={4}>

         
 
    
            <Typography variant='h5' sx={{ml:"50px"}}>Enter Custom Toast Text: </Typography><br></br>
            <TextField value={message} onChange={(e) => setMessage(e.target.value)} size={"small"} placeholder='Enter Here'/>
            <br></br>
            <br></br>
            <Button onClick={showToaster} variant="contained" sx={{textTransform:"capitalize"}}>Show custom toast message</Button>
               {toaster && 
                 <Box sx={{ position: "absolute", bottom: "50px", left: '50%', }}>
                     <ToasterCom2 message={message} clickClose={clickClose}/>
                 </Box>}
               
              
           
        </Box>
    );
}

export default Component2;
