import logo from './logo.svg';
import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Component1 from './Component/Component1';
import Component2 from './Component/Component2';
import Component3 from './Component/Component3';
import Header from './Component/Header';
import Footer1 from './Component/Footer1';
import { Box } from '@mui/material';



function App() {
  return (
    <div className="App">


      <BrowserRouter>
            <Header/>
        <Routes>

          <Route path="/" element={<Component1 />} > </Route>

          <Route exact path='/comp' element={<Component2 />}></Route>
          <Route exact path='/comp3' element={<Component3 />}></Route>
        </Routes>

      </BrowserRouter>
      <Box sx={{ position: "fixed",
                       bottom: 0,
                       flex: 1,
                    
                    
                       width: "100%",
                      
                        }}>
      <Footer1/>
      </Box>
    
    </div>
  );
}

export default App;
